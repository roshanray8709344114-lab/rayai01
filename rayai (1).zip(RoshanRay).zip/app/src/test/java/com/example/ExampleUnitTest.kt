package com.example

import com.example.data.model.ChatMessage
import com.example.data.model.ChatSession
import com.example.ui.components.MarkdownBlock
import com.example.ui.components.parseMarkdown
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testParseMarkdownCodeBlock() {
        val markdown = "```kotlin\nval x = 42\n```"
        val blocks = parseMarkdown(markdown)
        assertEquals(1, blocks.size)
        assertTrue(blocks[0] is MarkdownBlock.CodeBlock)
        val codeBlock = blocks[0] as MarkdownBlock.CodeBlock
        assertEquals("kotlin", codeBlock.language)
        assertEquals("val x = 42", codeBlock.code)
    }

    @Test
    fun testParseMarkdownHeadingsAndBullets() {
        val markdown = "# Heading 1\n* Bullet item 1\n* Bullet item 2"
        val blocks = parseMarkdown(markdown)
        assertEquals(3, blocks.size)
        assertTrue(blocks[0] is MarkdownBlock.Heading)
        assertTrue(blocks[1] is MarkdownBlock.BulletItem)
    }

    @Test
    fun testChatModelsCreation() {
        val session = ChatSession(id = "s-1", title = "Test Session")
        val message = ChatMessage(id = "m-1", sessionId = "s-1", role = "user", content = "Hello RayAI")
        assertEquals("s-1", session.id)
        assertEquals("Hello RayAI", message.content)
    }

    @Test
    fun testGeminiUiState() {
        val streaming = com.example.ui.viewmodel.GeminiUiState.Streaming("Thinking...")
        assertEquals("Thinking...", streaming.text)
        val success = com.example.ui.viewmodel.GeminiUiState.Success("Hello World")
        assertEquals("Hello World", success.text)
    }

    @Test
    fun testRoomEntityMapping() {
        val sessionEntity = com.example.data.local.ChatSessionEntity(
            id = "sess-123",
            title = "Android Architecture",
            createdAt = 1000L,
            updatedAt = 2000L
        )
        val messageEntity = com.example.data.local.ChatMessageEntity(
            id = "msg-123",
            sessionId = "sess-123",
            role = "user",
            content = "Explain Room Database",
            timestamp = 2000L,
            isError = false
        )

        assertEquals("sess-123", sessionEntity.id)
        assertEquals("Android Architecture", sessionEntity.title)
        assertEquals("msg-123", messageEntity.id)
        assertEquals("Explain Room Database", messageEntity.content)
        assertEquals("user", messageEntity.role)
    }

    @Test
    fun testExportChatHistoryFormat() {
        val title = "Machine Learning Basics"
        val timestamp = "2026-11-07 06:30:00"
        val userContent = "What is deep learning?"
        val modelContent = "Deep learning is a subset of machine learning based on artificial neural networks."

        val formatted = StringBuilder().apply {
            append("====================================================\n")
            append("RayAI Conversation Backup\n")
            append("Tagline: Intelligence Beyond Limits\n")
            append("Title: $title\n")
            append("Exported: $timestamp\n")
            append("====================================================\n\n")
            append("[06:30:01] USER:\n$userContent\n\n----------------------------------------------------\n\n")
            append("[06:30:05] RAYAI:\n$modelContent\n\n----------------------------------------------------\n\n")
        }.toString()

        assertTrue(formatted.contains("RayAI Conversation Backup"))
        assertTrue(formatted.contains("Tagline: Intelligence Beyond Limits"))
        assertTrue(formatted.contains("Machine Learning Basics"))
        assertTrue(formatted.contains("What is deep learning?"))
        assertTrue(formatted.contains("artificial neural networks"))
    }
}
