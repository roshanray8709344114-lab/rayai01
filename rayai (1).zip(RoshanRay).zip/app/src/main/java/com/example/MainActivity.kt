package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.example.data.ai.configureAppCheck
import com.example.ui.ChatScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.RayAiViewModel
import java.io.InputStream
import java.util.Locale

private const val TAG = "MainActivity"

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private val viewModel: RayAiViewModel by viewModels()
    private val geminiViewModel: com.example.ui.viewmodel.GeminiViewModel by viewModels()
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false
    private var speechRecognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Mandatory App Check configuration with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        // Initialize TextToSpeech engine
        textToSpeech = TextToSpeech(this, this)

        setContent {
            MyApplicationTheme {
                var isListeningVoice by remember { mutableStateOf(false) }

                // Photo picker launcher (zero-permission standard Android photo picker)
                val photoPickerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.PickVisualMedia()
                ) { uri: Uri? ->
                    if (uri != null) {
                        val bitmap = loadScaledBitmap(uri)
                        viewModel.setAttachedImage(uri, bitmap)
                    }
                }

                // Audio permission launcher for speech dictation
                val audioPermissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    if (isGranted) {
                        startVoiceRecognition(
                            onListeningChanged = { isListeningVoice = it },
                            onResult = { text ->
                                val current = viewModel.promptInput.value
                                val combined = if (current.isBlank()) text else "$current $text"
                                viewModel.setPromptInput(combined)
                            }
                        )
                    } else {
                        Toast.makeText(this, "Audio permission needed for speech input", Toast.LENGTH_SHORT).show()
                    }
                }

                var pendingExportContent by remember { mutableStateOf<String?>(null) }
                val exportFileLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.CreateDocument("text/plain")
                ) { uri: Uri? ->
                    if (uri != null && pendingExportContent != null) {
                        try {
                            contentResolver.openOutputStream(uri)?.use { outputStream ->
                                outputStream.write(pendingExportContent!!.toByteArray(Charsets.UTF_8))
                                outputStream.flush()
                            }
                            Toast.makeText(this, "Chat history saved successfully", Toast.LENGTH_LONG).show()
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to export chat file", e)
                            Toast.makeText(this, "Failed to save file: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                        }
                    }
                    pendingExportContent = null
                }

                ChatScreen(
                    viewModel = viewModel,
                    geminiViewModel = geminiViewModel,
                    onPickImage = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onExportChat = {
                        val plainText = viewModel.exportChatHistoryAsText()
                        pendingExportContent = plainText
                        val currentSession = viewModel.sessions.value.find { it.id == viewModel.currentSessionId.value }
                        val safeTitle = (currentSession?.title ?: "rayai_chat")
                            .replace(Regex("[^a-zA-Z0-9_-]"), "_")
                            .take(24)
                        val fileName = "${safeTitle}_backup_${System.currentTimeMillis() / 1000}.txt"
                        exportFileLauncher.launch(fileName)
                    },
                    onVoiceInputClick = {
                        if (isListeningVoice) {
                            stopVoiceRecognition(onListeningChanged = { isListeningVoice = it })
                        } else {
                            val hasPermission = ContextCompat.checkSelfPermission(
                                this,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED

                            if (hasPermission) {
                                startVoiceRecognition(
                                    onListeningChanged = { isListeningVoice = it },
                                    onResult = { text ->
                                        val currentRay = viewModel.promptInput.value
                                        val combinedRay = if (currentRay.isBlank()) text else "$currentRay $text"
                                        viewModel.setPromptInput(combinedRay)

                                        val currentGemini = geminiViewModel.currentQuery.value
                                        val combinedGemini = if (currentGemini.isBlank()) text else "$currentGemini $text"
                                        geminiViewModel.setQuery(combinedGemini)
                                    }
                                )
                            } else {
                                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    },
                    isListeningVoice = isListeningVoice,
                    onSpeakMessage = { text -> speakOut(text) },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = textToSpeech?.setLanguage(Locale.US)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.w(TAG, "TTS language is not supported")
            } else {
                isTtsReady = true
            }
        } else {
            Log.e(TAG, "TTS initialization failed")
        }
    }

    private fun speakOut(text: String) {
        if (!isTtsReady || textToSpeech == null) {
            Toast.makeText(this, "Speech engine initializing...", Toast.LENGTH_SHORT).show()
            return
        }
        // Strip markdown fences for cleaner voice reading
        val cleanText = text
            .replace(Regex("```[a-zA-Z]*"), "")
            .replace("```", "")
            .replace(Regex("\\*\\*|\\*"), "")
            .replace(Regex("#+\\s"), "")
            .trim()

        textToSpeech?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, "rayai_speech_id")
    }

    private fun startVoiceRecognition(
        onListeningChanged: (Boolean) -> Unit,
        onResult: (String) -> Unit
    ) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition not available on this device", Toast.LENGTH_SHORT).show()
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                onListeningChanged(true)
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                onListeningChanged(false)
            }

            override fun onError(error: Int) {
                onListeningChanged(false)
                Log.w(TAG, "Speech recognition error code: $error")
            }

            override fun onResults(results: Bundle?) {
                onListeningChanged(false)
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    onResult(matches[0])
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    onResult(matches[0])
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(intent)
    }

    private fun stopVoiceRecognition(onListeningChanged: (Boolean) -> Unit) {
        speechRecognizer?.stopListening()
        onListeningChanged(false)
    }

    private fun loadScaledBitmap(uri: Uri): Bitmap? {
        return try {
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeStream(inputStream, null, boundsOptions)
            inputStream?.close()

            // 1024px is optimal for Gemini Multimodal: sharp recognition with minimal payload transfer time
            val maxDimension = 1024
            var sampleSize = 1
            while (boundsOptions.outWidth / sampleSize > maxDimension || boundsOptions.outHeight / sampleSize > maxDimension) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.RGB_565 // 50% memory reduction and faster upload
            }
            val stream: InputStream? = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(stream, null, decodeOptions)
            stream?.close()
            bitmap
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load and scale bitmap", e)
            null
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        configureAppCheck(this, intent)
    }

    override fun onDestroy() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        speechRecognizer?.destroy()
        super.onDestroy()
    }
}
