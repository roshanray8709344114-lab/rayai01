package com.example.data.repository

import com.example.data.local.ChatDao
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatSessionEntity
import com.example.data.model.ChatMessage
import com.example.data.model.ChatSession
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ChatRepository(private val chatDao: ChatDao) {

    fun getAllSessions(): Flow<List<ChatSession>> {
        return chatDao.getAllSessions().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    suspend fun getSession(sessionId: String): ChatSession? {
        return chatDao.getSessionById(sessionId)?.toDomain()
    }

    suspend fun createSession(session: ChatSession) {
        chatDao.insertSession(
            ChatSessionEntity(
                id = session.id,
                title = session.title,
                createdAt = session.createdAt,
                updatedAt = session.updatedAt
            )
        )
    }

    suspend fun updateSessionTitle(sessionId: String, title: String) {
        chatDao.updateSessionTitle(sessionId, title)
    }

    suspend fun deleteSession(sessionId: String) {
        chatDao.deleteSession(sessionId)
    }

    fun getMessagesForSession(sessionId: String): Flow<List<ChatMessage>> {
        return chatDao.getMessagesForSession(sessionId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    suspend fun getMessagesList(sessionId: String): List<ChatMessage> {
        return chatDao.getMessagesListForSession(sessionId).map { it.toDomain() }
    }

    suspend fun saveMessage(message: ChatMessage) {
        chatDao.insertMessage(
            ChatMessageEntity(
                id = message.id,
                sessionId = message.sessionId,
                role = message.role,
                content = message.content,
                imageUri = message.imageUri,
                timestamp = message.timestamp,
                isError = message.isError
            )
        )
        // Also update session updatedAt timestamp
        chatDao.updateSessionTitle(
            sessionId = message.sessionId,
            title = chatDao.getSessionById(message.sessionId)?.title ?: "New Chat",
            updatedAt = System.currentTimeMillis()
        )
    }

    suspend fun updateMessageContent(messageId: String, content: String) {
        chatDao.updateMessageContent(messageId, content)
    }

    suspend fun clearAll() {
        chatDao.clearAllSessions()
    }

    private fun ChatSessionEntity.toDomain() = ChatSession(
        id = id,
        title = title,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    private fun ChatMessageEntity.toDomain() = ChatMessage(
        id = id,
        sessionId = sessionId,
        role = role,
        content = content,
        imageUri = imageUri,
        timestamp = timestamp,
        isError = isError
    )
}
