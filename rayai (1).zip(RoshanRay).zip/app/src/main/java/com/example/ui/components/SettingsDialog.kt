package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ai.DEFAULT_MODEL
import com.example.data.ai.LITE_MODEL
import com.example.data.ai.RAY_AI_SYSTEM_PROMPT
import com.example.ui.theme.RayCyan
import com.example.ui.theme.RayViolet
import com.example.ui.theme.SpaceBackground
import com.example.ui.theme.SpaceCardBg
import com.example.ui.theme.SpaceCardBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsBottomSheet(
    currentModel: String,
    currentTemperature: Float,
    onSaveSettings: (String, Float) -> Unit,
    onClearAllChats: () -> Unit,
    onDismiss: () -> Unit
) {
    var selectedModel by remember { mutableStateOf(currentModel) }
    var temperature by remember { mutableFloatStateOf(currentTemperature) }
    var showPromptDetails by remember { mutableStateOf(false) }
    var showClearConfirmation by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SpaceBackground,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = RayCyan,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "RayAI Settings",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Intelligence Beyond Limits",
                        fontSize = 12.sp,
                        color = RayCyan
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = SpaceCardBorder)
            Spacer(modifier = Modifier.height(16.dp))

            // AI Model Selection
            Text(
                text = "GEMINI MODEL",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = selectedModel == DEFAULT_MODEL,
                    onClick = {
                        selectedModel = DEFAULT_MODEL
                        onSaveSettings(selectedModel, temperature)
                    },
                    label = { Text("Gemini 3.8 Flash (Default)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = RayCyan.copy(alpha = 0.2f),
                        selectedLabelColor = RayCyan
                    ),
                    modifier = Modifier.weight(1f).padding(end = 4.dp).testTag("model_chip_flash")
                )

                FilterChip(
                    selected = selectedModel == LITE_MODEL,
                    onClick = {
                        selectedModel = LITE_MODEL
                        onSaveSettings(selectedModel, temperature)
                    },
                    label = { Text("Flash-Lite (Fast)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = RayCyan.copy(alpha = 0.2f),
                        selectedLabelColor = RayCyan
                    ),
                    modifier = Modifier.weight(1f).padding(start = 4.dp).testTag("model_chip_lite")
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Temperature Slider
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "CREATIVITY (TEMPERATURE)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted,
                    letterSpacing = 1.sp,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = String.format("%.2f", temperature),
                    color = RayCyan,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Slider(
                value = temperature,
                onValueChange = {
                    temperature = it
                    onSaveSettings(selectedModel, temperature)
                },
                valueRange = 0.0f..1.0f,
                colors = SliderDefaults.colors(
                    thumbColor = RayCyan,
                    activeTrackColor = RayCyan,
                    inactiveTrackColor = SpaceCardBorder
                ),
                modifier = Modifier.testTag("temperature_slider")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Precise & Focused",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "Creative & Expressive",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
            HorizontalDivider(color = SpaceCardBorder)
            Spacer(modifier = Modifier.height(16.dp))

            // Persona & Identity info
            Surface(
                onClick = { showPromptDetails = !showPromptDetails },
                shape = RoundedCornerShape(10.dp),
                color = SpaceCardBg,
                border = androidx.compose.foundation.BorderStroke(1.dp, SpaceCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = RayCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "RayAI System Instructions & Identity",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = if (showPromptDetails) "Hide" else "View",
                            fontSize = 12.sp,
                            color = RayCyan
                        )
                    }

                    if (showPromptDetails) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF090D15))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = RAY_AI_SYSTEM_PROMPT,
                                fontSize = 11.sp,
                                lineHeight = 16.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFFCBD5E1)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Clear All Chats Button
            Button(
                onClick = { showClearConfirmation = true },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0x22EF4444)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("clear_all_chats_button")
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteForever,
                    contentDescription = null,
                    tint = Color(0xFFEF4444),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Clear All Conversations",
                    color = Color(0xFFEF4444),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    if (showClearConfirmation) {
        AlertDialog(
            onDismissRequest = { showClearConfirmation = false },
            title = { Text("Clear All Conversations?", color = TextPrimary) },
            text = { Text("This will permanently delete all chat history across all sessions.", color = TextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        onClearAllChats()
                        showClearConfirmation = false
                        onDismiss()
                    }
                ) {
                    Text("Delete All", color = Color(0xFFEF4444))
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirmation = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = SpaceCardBg
        )
    }
}
