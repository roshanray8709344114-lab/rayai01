package com.example.ui.components

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.RayCyan
import com.example.ui.theme.RayViolet
import com.example.ui.theme.SpaceBackground
import com.example.ui.theme.SpaceCardBg
import com.example.ui.theme.SpaceCardBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatInputBar(
    promptText: String,
    onPromptChange: (String) -> Unit,
    attachedImageUri: Uri?,
    onRemoveAttachedImage: () -> Unit,
    onPickImage: () -> Unit,
    onVoiceInputClick: () -> Unit,
    isListeningVoice: Boolean,
    isGenerating: Boolean,
    onSend: () -> Unit,
    onStop: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = SpaceBackground,
        tonalElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // Attached Image Preview
            AnimatedVisibility(
                visible = attachedImageUri != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                if (attachedImageUri != null) {
                    Box(
                        modifier = Modifier
                            .padding(bottom = 8.dp)
                            .size(72.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, RayCyan, RoundedCornerShape(8.dp))
                    ) {
                        AsyncImage(
                            model = attachedImageUri,
                            contentDescription = "Attached image thumbnail",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxWidth().height(72.dp)
                        )

                        // Remove button
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(4.dp)
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(Color(0xCC000000)),
                            contentAlignment = Alignment.Center
                        ) {
                            IconButton(
                                onClick = onRemoveAttachedImage,
                                modifier = Modifier
                                    .size(20.dp)
                                    .testTag("remove_image_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Remove image",
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Input Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Attach Image Button
                IconButton(
                    onClick = onPickImage,
                    modifier = Modifier
                        .size(44.dp)
                        .testTag("attach_image_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = "Attach image",
                        tint = if (attachedImageUri != null) RayCyan else TextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Text Input
                OutlinedTextField(
                    value = promptText,
                    onValueChange = onPromptChange,
                    placeholder = {
                        Text(
                            text = if (isListeningVoice) "Listening..." else "Ask RayAI anything...",
                            color = if (isListeningVoice) RayCyan else TextMuted,
                            fontSize = 14.5.sp
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 4.dp)
                        .testTag("chat_input_text_field"),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = SpaceCardBg,
                        unfocusedContainerColor = SpaceCardBg,
                        focusedBorderColor = RayCyan,
                        unfocusedBorderColor = SpaceCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = RayCyan
                    ),
                    maxLines = 4,
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Sentences,
                        imeAction = ImeAction.Send
                    ),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if (!isGenerating && (promptText.isNotBlank() || attachedImageUri != null)) {
                                onSend()
                            }
                        }
                    )
                )

                // Voice Mic Button with pulsing listening effect
                val micTransition = androidx.compose.animation.core.rememberInfiniteTransition(label = "mic_pulse")
                val micScale by micTransition.animateFloat(
                    initialValue = 1f,
                    targetValue = if (isListeningVoice) 1.2f else 1f,
                    animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                        animation = androidx.compose.animation.core.tween(600, easing = androidx.compose.animation.core.EaseInOut),
                        repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
                    ),
                    label = "mic_scale"
                )

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(44.dp)
                ) {
                    if (isListeningVoice) {
                        Box(
                            modifier = Modifier
                                .size((38 * micScale).dp)
                                .clip(CircleShape)
                                .background(RayCyan.copy(alpha = 0.25f))
                        )
                    }
                    IconButton(
                        onClick = onVoiceInputClick,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = if (isListeningVoice) RayCyan else Color.Transparent
                        ),
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("voice_input_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = if (isListeningVoice) "Stop listening" else "Voice dictation input",
                            tint = if (isListeningVoice) Color(0xFF00363D) else TextSecondary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                // Send or Stop Generation Button
                if (isGenerating) {
                    IconButton(
                        onClick = onStop,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = Color(0xFFEF4444)
                        ),
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("stop_generation_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Stop generation",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                } else {
                    val canSend = promptText.isNotBlank() || attachedImageUri != null
                    IconButton(
                        onClick = onSend,
                        enabled = canSend,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = if (canSend) RayCyan else Color(0xFF1E293B),
                            disabledContainerColor = Color(0xFF1E293B)
                        ),
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("send_message_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send message",
                            tint = if (canSend) Color(0xFF00363D) else TextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
