package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// RayAI Neon Cyber / Deep Space Palette
val RayCyan = Color(0xFF00E5FF)
val RayCyanMuted = Color(0xFF00B4D8)
val RayViolet = Color(0xFFA855F7)
val RayVioletDark = Color(0xFF7C3AED)
val RayBlue = Color(0xFF3B82F6)

// Dark Theme Backgrounds & Surfaces
val SpaceBackground = Color(0xFF0B0F19)
val SpaceCardBg = Color(0xFF131B2E)
val SpaceCardBorder = Color(0xFF1F2E4D)
val SpaceSurface = Color(0xFF182238)
val SpaceSurfaceLight = Color(0xFF22304E)
val SpaceCodeBg = Color(0xFF070A12)

// Text Colors
val TextPrimary = Color(0xFFF3F4F6)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)

// Accent Glows
val GlowCyan = Color(0x3300E5FF)
val GlowViolet = Color(0x33A855F7)

// User / AI message bubble backgrounds
val UserBubbleBg = Color(0xFF1E293B)
val AiBubbleBg = Color(0xFF131B2E)
val CodeBlockHeaderBg = Color(0xFF0F172A)
