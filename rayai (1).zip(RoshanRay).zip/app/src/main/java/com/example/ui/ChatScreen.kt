package com.example.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.ChatBubble
import com.example.ui.components.ChatInputBar
import com.example.ui.components.SessionsDrawerContent
import com.example.ui.components.SettingsBottomSheet
import com.example.ui.components.WelcomeHeroCard
import com.example.ui.theme.RayCyan
import com.example.ui.theme.RayViolet
import com.example.ui.theme.SpaceBackground
import com.example.ui.theme.SpaceCardBg
import com.example.ui.theme.SpaceCardBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.RayAiViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: RayAiViewModel,
    geminiViewModel: com.example.ui.viewmodel.GeminiViewModel? = null,
    onPickImage: () -> Unit,
    onExportChat: () -> Unit = {},
    onVoiceInputClick: () -> Unit,
    isListeningVoice: Boolean,
    onSpeakMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val currentSessionId by viewModel.currentSessionId.collectAsState()
    val sessions by viewModel.sessions.collectAsState()
    val messages by viewModel.currentMessages.collectAsState()
    val streamingMessage by viewModel.streamingMessage.collectAsState()
    val promptInput by viewModel.promptInput.collectAsState()
    val attachedImageUri by viewModel.attachedImageUri.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val selectedModel by viewModel.selectedModel.collectAsState()
    val temperature by viewModel.temperature.collectAsState()

    var showSettings by remember { mutableStateOf(false) }
    var showGeminiConsole by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()

    // Auto-scroll to bottom on new messages or streaming chunks
    LaunchedEffect(messages.size, streamingMessage?.content?.length) {
        val totalCount = messages.size + (if (streamingMessage != null) 1 else 0)
        if (totalCount > 0) {
            listState.animateScrollToItem(totalCount - 1)
        }
    }

    // Handle back button when drawer is open
    BackHandler(enabled = drawerState.isOpen) {
        scope.launch { drawerState.close() }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            SessionsDrawerContent(
                sessions = sessions,
                currentSessionId = currentSessionId,
                onSelectSession = { id ->
                    viewModel.selectSession(id)
                    scope.launch { drawerState.close() }
                },
                onNewChat = {
                    viewModel.startNewSession()
                    scope.launch { drawerState.close() }
                },
                onRenameSession = { id, title -> viewModel.renameSession(id, title) },
                onDeleteSession = { id -> viewModel.deleteSession(id) },
                onOpenSettings = {
                    scope.launch { drawerState.close() }
                    showSettings = true
                },
                onExportChat = {
                    scope.launch { drawerState.close() }
                    onExportChat()
                },
                onOpenGeminiConsole = {
                    scope.launch { drawerState.close() }
                    showGeminiConsole = true
                }
            )
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(RayCyan, RayViolet)))
                                    .padding(1.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF0B0F19)),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.rayai_logo),
                                    contentDescription = "RayAI",
                                    modifier = Modifier.size(24.dp),
                                    contentScale = ContentScale.Fit
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "RayAI",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Intelligence Beyond Limits",
                                    fontSize = 10.5.sp,
                                    color = RayCyan
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { scope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Open conversation history",
                                tint = TextPrimary
                            )
                        }
                    },
                    actions = {
                        // Export Chat History Button
                        IconButton(
                            onClick = onExportChat,
                            enabled = messages.isNotEmpty(),
                            modifier = Modifier.testTag("top_bar_export_chat_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.FileDownload,
                                contentDescription = "Export chat history",
                                tint = if (messages.isNotEmpty()) RayCyan else TextMuted
                            )
                        }

                        // New Chat shortcut button
                        IconButton(
                            onClick = { viewModel.startNewSession() },
                            modifier = Modifier.testTag("top_bar_new_chat_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "New chat",
                                tint = RayCyan
                            )
                        }

                        // Settings button
                        IconButton(
                            onClick = { showSettings = true },
                            modifier = Modifier.testTag("top_bar_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = TextSecondary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = SpaceBackground
                    )
                )
            },
            bottomBar = {
                ChatInputBar(
                    promptText = promptInput,
                    onPromptChange = { viewModel.setPromptInput(it) },
                    attachedImageUri = attachedImageUri,
                    onRemoveAttachedImage = { viewModel.clearAttachedImage() },
                    onPickImage = onPickImage,
                    onVoiceInputClick = onVoiceInputClick,
                    isListeningVoice = isListeningVoice,
                    isGenerating = isGenerating,
                    onSend = { viewModel.sendMessage() },
                    onStop = { viewModel.stopGeneration() }
                )
            },
            containerColor = SpaceBackground,
            modifier = modifier.fillMaxSize()
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                if (messages.isEmpty() && streamingMessage == null) {
                    // Welcome & Quick-start screen
                    LazyColumn(
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            WelcomeHeroCard(
                                onSelectPrompt = { prompt ->
                                    viewModel.setPromptInput(prompt)
                                    viewModel.sendMessage(prompt)
                                }
                            )
                        }
                    }
                } else {
                    // Messages list
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 4.dp, vertical = 8.dp)
                    ) {
                        items(messages, key = { it.id }) { msg ->
                            ChatBubble(
                                message = msg,
                                onSpeakMessage = onSpeakMessage,
                                onRetry = { viewModel.retryLastMessage() }
                            )
                        }

                        if (streamingMessage != null) {
                            item(key = "streaming_msg") {
                                ChatBubble(
                                    message = streamingMessage!!,
                                    onSpeakMessage = onSpeakMessage
                                )
                            }
                        }
                    }
                }

                // Error Snackbar / Floating Banner
                AnimatedVisibility(
                    visible = errorMessage != null,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(16.dp)
                ) {
                    if (errorMessage != null) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFF7F1D1D),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(12.dp)
                            ) {
                                Text(
                                    text = errorMessage!!,
                                    color = Color(0xFFFEE2E2),
                                    fontSize = 13.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { viewModel.clearErrorMessage() },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Dismiss error",
                                        tint = Color(0xFFFEE2E2),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSettings) {
        SettingsBottomSheet(
            currentModel = selectedModel,
            currentTemperature = temperature,
            onSaveSettings = { model, temp ->
                viewModel.updateSettings(model, temp)
            },
            onClearAllChats = { viewModel.clearAllChats() },
            onDismiss = { showSettings = false }
        )
    }

    if (showGeminiConsole && geminiViewModel != null) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showGeminiConsole = false },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                com.example.ui.components.GeminiUiWrapper(
                    viewModel = geminiViewModel,
                    onVoiceInputClick = onVoiceInputClick,
                    isListeningVoice = isListeningVoice
                )
                IconButton(
                    onClick = { showGeminiConsole = false },
                    modifier = Modifier
                        .statusBarsPadding()
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .testTag("close_gemini_console_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Gemini Console",
                        tint = TextSecondary
                    )
                }
            }
        }
    }
}
