package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CodeBlockHeaderBg
import com.example.ui.theme.RayCyan
import com.example.ui.theme.SpaceCodeBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

sealed interface MarkdownBlock {
    data class Paragraph(val text: String) : MarkdownBlock
    data class Heading(val level: Int, val text: String) : MarkdownBlock
    data class CodeBlock(val language: String, val code: String) : MarkdownBlock
    data class BulletItem(val text: String) : MarkdownBlock
    data class NumberedItem(val number: String, val text: String) : MarkdownBlock
    data class BlockQuote(val text: String) : MarkdownBlock
    data class Table(val headers: List<String>, val rows: List<List<String>>) : MarkdownBlock
}

fun parseMarkdown(raw: String): List<MarkdownBlock> {
    val blocks = mutableListOf<MarkdownBlock>()
    val lines = raw.lines()
    var i = 0

    while (i < lines.size) {
        val line = lines[i]

        // 1. Fenced Code Block
        if (line.trimStart().startsWith("```")) {
            val language = line.trimStart().removePrefix("```").trim()
            val codeLines = mutableListOf<String>()
            i++
            while (i < lines.size && !lines[i].trimStart().startsWith("```")) {
                codeLines.add(lines[i])
                i++
            }
            blocks.add(MarkdownBlock.CodeBlock(language.ifEmpty { "code" }, codeLines.joinToString("\n")))
            i++
            continue
        }

        // 2. Heading
        if (line.startsWith("#")) {
            val level = line.takeWhile { it == '#' }.length
            if (level in 1..6 && line.length > level && line[level] == ' ') {
                val text = line.substring(level + 1).trim()
                blocks.add(MarkdownBlock.Heading(level, text))
                i++
                continue
            }
        }

        // 3. Blockquote
        if (line.startsWith(">")) {
            val quoteLines = mutableListOf(line.removePrefix(">").trim())
            i++
            while (i < lines.size && lines[i].startsWith(">")) {
                quoteLines.add(lines[i].removePrefix(">").trim())
                i++
            }
            blocks.add(MarkdownBlock.BlockQuote(quoteLines.joinToString(" ")))
            continue
        }

        // 4. Bullet List
        if (line.trimStart().startsWith("* ") || line.trimStart().startsWith("- ")) {
            val bulletText = line.trimStart().drop(2)
            blocks.add(MarkdownBlock.BulletItem(bulletText))
            i++
            continue
        }

        // 5. Numbered List (e.g. "1. ")
        val numberedMatch = Regex("^\\s*(\\d+)\\.\\s+(.+)").find(line)
        if (numberedMatch != null) {
            val num = numberedMatch.groupValues[1]
            val text = numberedMatch.groupValues[2]
            blocks.add(MarkdownBlock.NumberedItem(num, text))
            i++
            continue
        }

        // 6. Simple Table detection (| a | b |)
        if (line.trim().startsWith("|") && line.trim().endsWith("|") && i + 1 < lines.size && lines[i + 1].contains("---")) {
            val headers = line.split("|").map { it.trim() }.filter { it.isNotEmpty() }
            i += 2 // skip header and divider
            val tableRows = mutableListOf<List<String>>()
            while (i < lines.size && lines[i].trim().startsWith("|") && lines[i].trim().endsWith("|")) {
                val row = lines[i].split("|").map { it.trim() }.filter { it.isNotEmpty() }
                if (row.isNotEmpty()) tableRows.add(row)
                i++
            }
            blocks.add(MarkdownBlock.Table(headers, tableRows))
            continue
        }

        // 7. Regular paragraph / empty line
        if (line.isNotBlank()) {
            val paraLines = mutableListOf(line)
            i++
            while (i < lines.size && lines[i].isNotBlank() &&
                !lines[i].trimStart().startsWith("```") &&
                !lines[i].startsWith("#") &&
                !lines[i].startsWith(">") &&
                !lines[i].trimStart().startsWith("* ") &&
                !lines[i].trimStart().startsWith("- ") &&
                !Regex("^\\s*\\d+\\.\\s+").containsMatchIn(lines[i])
            ) {
                paraLines.add(lines[i])
                i++
            }
            blocks.add(MarkdownBlock.Paragraph(paraLines.joinToString("\n")))
        } else {
            i++
        }
    }

    return blocks
}

@Composable
fun MarkdownContent(
    content: String,
    modifier: Modifier = Modifier,
    textColor: Color = TextPrimary
) {
    // Memoize markdown AST parse to eliminate redundant re-parsing during real-time streaming
    val blocks = androidx.compose.runtime.remember(content) { parseMarkdown(content) }

    Column(modifier = modifier) {
        blocks.forEachIndexed { index, block ->
            when (block) {
                is MarkdownBlock.Heading -> {
                    val fontSize = when (block.level) {
                        1 -> 22.sp
                        2 -> 19.sp
                        3 -> 17.sp
                        else -> 15.sp
                    }
                    Text(
                        text = buildInlineMarkdown(block.text, textColor),
                        fontSize = fontSize,
                        fontWeight = FontWeight.Bold,
                        color = RayCyan,
                        modifier = Modifier.padding(top = if (index > 0) 12.dp else 2.dp, bottom = 4.dp)
                    )
                }

                is MarkdownBlock.Paragraph -> {
                    Text(
                        text = buildInlineMarkdown(block.text, textColor),
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        color = textColor,
                        modifier = Modifier.padding(vertical = 3.dp)
                    )
                }

                is MarkdownBlock.BulletItem -> {
                    Row(
                        modifier = Modifier.padding(vertical = 2.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "•",
                            color = RayCyan,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Text(
                            text = buildInlineMarkdown(block.text, textColor),
                            fontSize = 15.sp,
                            lineHeight = 22.sp,
                            color = textColor
                        )
                    }
                }

                is MarkdownBlock.NumberedItem -> {
                    Row(
                        modifier = Modifier.padding(vertical = 2.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "${block.number}.",
                            color = RayCyan,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.width(24.dp)
                        )
                        Text(
                            text = buildInlineMarkdown(block.text, textColor),
                            fontSize = 15.sp,
                            lineHeight = 22.sp,
                            color = textColor
                        )
                    }
                }

                is MarkdownBlock.BlockQuote -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .background(Color(0x1A00E5FF), RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(20.dp)
                                .background(RayCyan, RoundedCornerShape(2.dp))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = buildInlineMarkdown(block.text, TextSecondary),
                            fontStyle = FontStyle.Italic,
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            color = TextSecondary
                        )
                    }
                }

                is MarkdownBlock.CodeBlock -> {
                    CodeBlockItem(
                        language = block.language,
                        code = block.code,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                }

                is MarkdownBlock.Table -> {
                    TableBlockItem(
                        headers = block.headers,
                        rows = block.rows,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun CodeBlockItem(
    language: String,
    code: String,
    modifier: Modifier = Modifier
) {
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(SpaceCodeBg)
            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CodeBlockHeaderBg)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = language.uppercase(),
                color = RayCyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.weight(1f)
            )

            IconButton(
                onClick = {
                    clipboardManager.setText(AnnotatedString(code))
                    Toast.makeText(context, "Code copied to clipboard", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .size(32.dp)
                    .testTag("copy_code_button")
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy code",
                    tint = TextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Code Content
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            Text(
                text = code,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                lineHeight = 19.sp,
                color = Color(0xFFE2E8F0)
            )
        }
    }
}

@Composable
fun TableBlockItem(
    headers: List<String>,
    rows: List<List<String>>,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(6.dp))
            .horizontalScroll(rememberScrollState())
    ) {
        Column {
            // Header row
            Row(
                modifier = Modifier
                    .background(Color(0xFF1E293B))
                    .padding(8.dp)
            ) {
                headers.forEach { header ->
                    Text(
                        text = header,
                        fontWeight = FontWeight.Bold,
                        color = RayCyan,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .width(130.dp)
                            .padding(horizontal = 4.dp)
                    )
                }
            }

            // Data rows
            rows.forEachIndexed { idx, row ->
                Row(
                    modifier = Modifier
                        .background(if (idx % 2 == 0) Color(0xFF0F172A) else Color(0xFF172033))
                        .padding(8.dp)
                ) {
                    row.forEach { cell ->
                        Text(
                            text = cell,
                            color = TextPrimary,
                            fontSize = 13.sp,
                            modifier = Modifier
                                .width(130.dp)
                                .padding(horizontal = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Parses inline formatting like **bold**, *italic*, `code`, and $math$
 */
fun buildInlineMarkdown(text: String, defaultColor: Color): AnnotatedString {
    return buildAnnotatedString {
        var cursor = 0
        val regex = Regex("(`[^`]+`)|(\\*\\*[^*]+\\*\\*)|(\\*[^*]+\\*)|(\\$[^$]+\\$)")
        val matches = regex.findAll(text)

        for (match in matches) {
            val range = match.range
            if (range.first > cursor) {
                append(text.substring(cursor, range.first))
            }

            val value = match.value
            when {
                value.startsWith("`") && value.endsWith("`") -> {
                    val code = value.removeSurrounding("`")
                    pushStyle(
                        SpanStyle(
                            fontFamily = FontFamily.Monospace,
                            background = Color(0x3300E5FF),
                            color = RayCyan,
                            fontSize = 13.5.sp
                        )
                    )
                    append(" $code ")
                    pop()
                }

                value.startsWith("**") && value.endsWith("**") -> {
                    val bold = value.removeSurrounding("**")
                    pushStyle(SpanStyle(fontWeight = FontWeight.Bold, color = defaultColor))
                    append(bold)
                    pop()
                }

                value.startsWith("*") && value.endsWith("*") -> {
                    val italic = value.removeSurrounding("*")
                    pushStyle(SpanStyle(fontStyle = FontStyle.Italic, color = defaultColor))
                    append(italic)
                    pop()
                }

                value.startsWith("$") && value.endsWith("$") -> {
                    val math = value.removeSurrounding("$")
                    pushStyle(
                        SpanStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF67E8F9)
                        )
                    )
                    append(math)
                    pop()
                }

                else -> append(value)
            }
            cursor = range.last + 1
        }

        if (cursor < text.length) {
            append(text.substring(cursor))
        }
    }
}
