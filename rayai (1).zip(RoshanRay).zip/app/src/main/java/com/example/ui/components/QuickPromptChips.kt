package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.RayCyan
import com.example.ui.theme.RayViolet
import com.example.ui.theme.SpaceCardBg
import com.example.ui.theme.SpaceCardBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class QuickPrompt(
    val title: String,
    val icon: ImageVector,
    val prompt: String,
    val tag: String
)

val QUICK_PROMPTS = listOf(
    QuickPrompt(
        title = "Code Helper",
        icon = Icons.Default.Code,
        prompt = "Write clean, idiomatic Kotlin code for a custom Compose shimmer effect and briefly explain the approach.",
        tag = "code"
    ),
    QuickPrompt(
        title = "Explain Concept",
        icon = Icons.Default.School,
        prompt = "Explain how transformer neural networks work step-by-step using a simple, relatable analogy.",
        tag = "education"
    ),
    QuickPrompt(
        title = "Math & Reasoning",
        icon = Icons.Default.Functions,
        prompt = "Show your reasoning step-by-step to solve this probability problem: What is the probability of rolling at least one 6 in four fair dice rolls?",
        tag = "math"
    ),
    QuickPrompt(
        title = "Polish Writing",
        icon = Icons.Default.Create,
        prompt = "Improve the tone and clarity of this email to sound professional, persuasive, and respectful: 'Hey, did you look at the deck yet? We need to finalize it asap.'",
        tag = "writing"
    ),
    QuickPrompt(
        title = "Brainstorm Ideas",
        icon = Icons.Default.Lightbulb,
        prompt = "Give me 5 inventive and original mobile application concepts that use generative AI to solve everyday problems.",
        tag = "brainstorm"
    )
)

@Composable
fun WelcomeHeroCard(
    onSelectPrompt: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Glowing App Emblem
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(RayCyan.copy(alpha = 0.4f), Color.Transparent)
                    )
                )
                .padding(4.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(RayCyan, RayViolet)
                    )
                )
                .padding(2.dp)
                .clip(CircleShape)
                .background(Color(0xFF0B0F19)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.rayai_logo),
                contentDescription = "RayAI Logo",
                modifier = Modifier.size(60.dp),
                contentScale = ContentScale.Fit
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Title and Tagline
        Text(
            text = "RayAI",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(4.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = RayCyan,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Intelligence Beyond Limits",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = RayCyan
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Powered by Google Gemini • Fast, accurate, and conversational assistance for coding, reasoning, writing, and multimodal analysis.",
            fontSize = 13.sp,
            lineHeight = 18.sp,
            color = TextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Quick Suggestion Cards Grid
        Text(
            text = "TRY ASKING",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted,
            letterSpacing = 1.5.sp,
            modifier = Modifier
                .align(Alignment.Start)
                .padding(bottom = 12.dp)
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QUICK_PROMPTS.forEach { promptItem ->
                Surface(
                    onClick = { onSelectPrompt(promptItem.prompt) },
                    shape = RoundedCornerShape(12.dp),
                    color = SpaceCardBg,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SpaceCardBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("prompt_chip_${promptItem.tag}")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(RayCyan.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = promptItem.icon,
                                contentDescription = promptItem.title,
                                tint = RayCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = promptItem.title,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Text(
                                text = promptItem.prompt,
                                fontSize = 12.sp,
                                color = TextSecondary,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}
