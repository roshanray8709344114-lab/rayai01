package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.RayCyan
import com.example.ui.theme.RayViolet
import com.example.ui.theme.SpaceBackground
import com.example.ui.theme.SpaceCardBg
import com.example.ui.theme.SpaceCardBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.GeminiUiState
import com.example.ui.viewmodel.GeminiViewModel

@Composable
fun GeminiUiWrapper(
    viewModel: GeminiViewModel,
    onVoiceInputClick: (() -> Unit)? = null,
    isListeningVoice: Boolean = false,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val currentQuery by viewModel.currentQuery.collectAsState()
    val chatHistory by viewModel.chatHistory.collectAsState()
    val selectedModel by viewModel.selectedModel.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val isWaiting by viewModel.isWaiting.collectAsState()
    val listState = rememberLazyListState()

    val isProcessing = isGenerating || uiState is GeminiUiState.Loading || uiState is GeminiUiState.Streaming

    // Auto-scroll to bottom as new messages arrive
    LaunchedEffect(chatHistory.size, (uiState as? GeminiUiState.Streaming)?.text?.length) {
        val count = chatHistory.size + if (uiState is GeminiUiState.Streaming || uiState is GeminiUiState.Loading) 1 else 0
        if (count > 0) {
            listState.animateScrollToItem(count - 1)
        }
    }

    Surface(
        color = SpaceBackground,
        modifier = modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
        ) {
            // Header: Service status & model information
            Surface(
                color = SpaceCardBg,
                border = androidx.compose.foundation.BorderStroke(1.dp, SpaceCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(RayCyan, RayViolet)))
                            .padding(1.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF0B0F19)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.rayai_logo),
                            contentDescription = "RayAI",
                            modifier = Modifier.size(20.dp),
                            contentScale = ContentScale.Fit
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Firebase AI Service",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(RayCyan.copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = selectedModel,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = RayCyan
                                )
                            }
                        }
                        if (isGenerating || isWaiting) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    modifier = Modifier
                                        .size(11.dp)
                                        .testTag("gemini_header_progress_indicator"),
                                    strokeWidth = 1.5.dp,
                                    color = RayCyan
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isWaiting) "Connecting to Gemini service..." else "Generating response...",
                                    fontSize = 11.sp,
                                    color = RayCyan,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        } else {
                            Text(
                                text = "Initialized & Ready • App Check Attested",
                                fontSize = 11.sp,
                                color = Color(0xFF10B981)
                            )
                        }
                    }

                    if (chatHistory.isNotEmpty()) {
                        IconButton(
                            onClick = { viewModel.clearChatHistory() },
                            modifier = Modifier.size(32.dp).testTag("clear_gemini_history_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "Clear history",
                                tint = TextMuted,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            // Message History Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (chatHistory.isEmpty() && uiState is GeminiUiState.Idle) {
                    // Empty state prompts
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = RayCyan,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Firebase AI Service Ready",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Send a prompt to begin streaming Gemini model responses.",
                            fontSize = 13.sp,
                            color = TextSecondary,
                            modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
                        )

                        // Sample quick prompts
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Surface(
                                onClick = { viewModel.processQuery("Explain quantum computing in one sentence.") },
                                shape = RoundedCornerShape(10.dp),
                                color = SpaceCardBg,
                                border = androidx.compose.foundation.BorderStroke(1.dp, SpaceCardBorder),
                                modifier = Modifier.weight(1f).testTag("quick_query_1")
                            ) {
                                Text(
                                    text = "⚛️ Quantum computing",
                                    fontSize = 12.sp,
                                    color = TextPrimary,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }

                            Surface(
                                onClick = { viewModel.processQuery("Write a Kotlin function to reverse a string.") },
                                shape = RoundedCornerShape(10.dp),
                                color = SpaceCardBg,
                                border = androidx.compose.foundation.BorderStroke(1.dp, SpaceCardBorder),
                                modifier = Modifier.weight(1f).testTag("quick_query_2")
                            ) {
                                Text(
                                    text = "💻 Kotlin function",
                                    fontSize = 12.sp,
                                    color = TextPrimary,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 8.dp, vertical = 8.dp)
                    ) {
                        items(chatHistory, key = { it.id }) { msg ->
                            ChatBubble(
                                message = msg,
                                onSpeakMessage = {},
                                onRetry = if (msg.isError) {
                                    {
                                        val lastUser = chatHistory.lastOrNull { it.role == "user" }
                                        if (lastUser != null) {
                                            viewModel.processQuery(lastUser.content)
                                        }
                                    }
                                } else null
                            )
                        }

                        // Live state item if processing
                        if (isProcessing) {
                            item(key = "active_processing_indicator") {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = SpaceCardBg,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, RayCyan.copy(alpha = 0.4f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                        .testTag("gemini_active_generation_card")
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        if (isWaiting || uiState is GeminiUiState.Loading) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier
                                                        .size(24.dp)
                                                        .testTag("gemini_loading_circular_indicator"),
                                                    strokeWidth = 2.5.dp,
                                                    color = RayCyan
                                                )
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Column {
                                                    Text(
                                                        text = "Generating response with Gemini...",
                                                        fontSize = 13.sp,
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = RayCyan
                                                    )
                                                    Text(
                                                        text = "Contacting Firebase Genkit AI service",
                                                        fontSize = 11.sp,
                                                        color = TextMuted
                                                    )
                                                }
                                            }
                                        } else if (uiState is GeminiUiState.Streaming) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(bottom = 8.dp)
                                            ) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier
                                                        .size(16.dp)
                                                        .testTag("gemini_streaming_circular_indicator"),
                                                    strokeWidth = 2.dp,
                                                    color = RayCyan
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "Streaming from ${selectedModel}...",
                                                    fontSize = 11.sp,
                                                    color = RayCyan,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            }
                                            val streamingState = uiState as GeminiUiState.Streaming
                                            MarkdownContent(content = streamingState.text)
                                            Text(
                                                text = " ▌",
                                                color = RayCyan,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Input Bar
            Surface(
                color = SpaceCardBg,
                border = androidx.compose.foundation.BorderStroke(1.dp, SpaceCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    OutlinedTextField(
                        value = currentQuery,
                        onValueChange = { viewModel.setQuery(it) },
                        placeholder = { Text("Enter prompt for Gemini...", color = TextMuted, fontSize = 14.sp) },
                        maxLines = 3,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("gemini_query_input"),
                        shape = RoundedCornerShape(20.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = SpaceBackground,
                            unfocusedContainerColor = SpaceBackground,
                            focusedBorderColor = RayCyan,
                            unfocusedBorderColor = SpaceCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (!isProcessing && currentQuery.isNotBlank()) {
                                    viewModel.processQuery()
                                }
                            }
                        )
                    )

                    if (onVoiceInputClick != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = onVoiceInputClick,
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = if (isListeningVoice) RayCyan else Color.Transparent
                            ),
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("gemini_voice_input_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = if (isListeningVoice) "Stop listening" else "Voice input",
                                tint = if (isListeningVoice) Color(0xFF00363D) else TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    if (isProcessing) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier
                                    .size(20.dp)
                                    .testTag("gemini_input_circular_indicator"),
                                strokeWidth = 2.dp,
                                color = RayCyan
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(
                                onClick = { viewModel.stopProcessing() },
                                colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFFEF4444)),
                                modifier = Modifier.size(42.dp).testTag("gemini_stop_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Stop,
                                    contentDescription = "Stop",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    } else {
                        IconButton(
                            onClick = { viewModel.processQuery() },
                            enabled = currentQuery.isNotBlank(),
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = if (currentQuery.isNotBlank()) RayCyan else Color(0xFF1E293B),
                                disabledContainerColor = Color(0xFF1E293B)
                            ),
                            modifier = Modifier.size(42.dp).testTag("gemini_send_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send",
                                tint = if (currentQuery.isNotBlank()) Color(0xFF00363D) else TextMuted,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
