package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.DEFAULT_MODEL
import com.example.data.ai.LITE_MODEL
import com.example.data.ai.RAY_AI_SYSTEM_PROMPT
import com.example.data.model.ChatMessage
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.util.UUID

private const val TAG = "GeminiViewModel"

sealed interface GeminiUiState {
    data object Idle : GeminiUiState
    data object Loading : GeminiUiState
    data class Streaming(val text: String) : GeminiUiState
    data class Success(val text: String) : GeminiUiState
    data class Error(val message: String) : GeminiUiState
}

class GeminiViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: com.example.data.repository.ChatRepository
    private val sessionId = "gemini_service_console"

    private val _uiState = MutableStateFlow<GeminiUiState>(GeminiUiState.Idle)
    val uiState: StateFlow<GeminiUiState> = _uiState.asStateFlow()

    private val _currentQuery = MutableStateFlow("")
    val currentQuery: StateFlow<String> = _currentQuery.asStateFlow()

    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatHistory: StateFlow<List<ChatMessage>> = _chatHistory.asStateFlow()

    private val _selectedModel = MutableStateFlow(DEFAULT_MODEL)
    val selectedModel: StateFlow<String> = _selectedModel.asStateFlow()

    private val _temperature = MutableStateFlow(0.7f)
    val temperature: StateFlow<Float> = _temperature.asStateFlow()

    // Circular progress tracking indicators
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _isWaiting = MutableStateFlow(false)
    val isWaiting: StateFlow<Boolean> = _isWaiting.asStateFlow()

    private var activeJob: Job? = null

    init {
        val db = com.example.data.local.AppDatabase.getInstance(application)
        repository = com.example.data.repository.ChatRepository(db.chatDao())

        // Load existing persisted messages for Gemini service console and listen for updates
        viewModelScope.launch {
            // Ensure session entry exists in Room
            if (repository.getSession(sessionId) == null) {
                repository.createSession(
                    com.example.data.model.ChatSession(
                        id = sessionId,
                        title = "Gemini AI Console",
                        createdAt = System.currentTimeMillis(),
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
            repository.getMessagesForSession(sessionId).collect { persistedMessages ->
                _chatHistory.value = persistedMessages
            }
        }
    }

    // Lazy initialization of the Firebase AI / Genkit Gemini model
    private val generativeModel by lazy {
        Firebase.ai.generativeModel(
            modelName = _selectedModel.value,
            generationConfig = generationConfig {
                this.temperature = _temperature.value
            },
            systemInstruction = content {
                text(RAY_AI_SYSTEM_PROMPT)
            }
        )
    }

    private val fastLiteModel by lazy {
        Firebase.ai.generativeModel(
            modelName = LITE_MODEL,
            generationConfig = generationConfig {
                this.temperature = _temperature.value
            },
            systemInstruction = content {
                text(RAY_AI_SYSTEM_PROMPT)
            }
        )
    }

    fun setQuery(text: String) {
        _currentQuery.value = text
    }

    fun updateConfig(modelName: String, temp: Float) {
        _selectedModel.value = modelName
        _temperature.value = temp
    }

    fun clearChatHistory() {
        stopProcessing()
        _chatHistory.value = emptyList()
        _uiState.value = GeminiUiState.Idle
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            repository.createSession(
                com.example.data.model.ChatSession(
                    id = sessionId,
                    title = "Gemini AI Console",
                    createdAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    fun stopProcessing() {
        activeJob?.cancel()
        activeJob = null
        _isGenerating.value = false
        _isWaiting.value = false

        if (_uiState.value is GeminiUiState.Loading || _uiState.value is GeminiUiState.Streaming) {
            val lastOutput = when (val state = _uiState.value) {
                is GeminiUiState.Streaming -> state.text
                else -> ""
            }
            if (lastOutput.isNotBlank()) {
                _uiState.value = GeminiUiState.Success(lastOutput)
            } else {
                _uiState.value = GeminiUiState.Idle
            }
        }
    }

    /**
     * Sanitizes multi-turn history ensuring valid user/model turn alternation
     */
    private fun sanitizeHistory(history: List<ChatMessage>): List<Content> {
        val sanitized = mutableListOf<Content>()
        val valid = history.filter { !it.isError && it.content.isNotBlank() }

        var expectedRole = "user"
        for (msg in valid.takeLast(10)) {
            val role = if (msg.role == "user") "user" else "model"
            if (role == expectedRole) {
                sanitized.add(content(role) { text(msg.content.trim()) })
                expectedRole = if (expectedRole == "user") "model" else "user"
            }
        }

        if (sanitized.isNotEmpty() && expectedRole == "model") {
            sanitized.removeAt(sanitized.size - 1)
        }

        return sanitized
    }

    /**
     * Processes a user query with streaming, history context, and multimodal support.
     * Updates isGenerating and isWaiting to drive circular progress indicators in the UI.
     * Persists all turns into Room database.
     */
    fun processQuery(queryText: String? = null, bitmap: Bitmap? = null) {
        val query = (queryText ?: _currentQuery.value).trim()
        if (query.isBlank() && bitmap == null) return

        _currentQuery.value = ""
        val userMessage = ChatMessage(
            id = UUID.randomUUID().toString(),
            sessionId = sessionId,
            role = "user",
            content = query.ifEmpty { "Analyze attached image" },
            timestamp = System.currentTimeMillis()
        )

        // Append to history and persist immediately in Room
        val updatedHistory = _chatHistory.value + userMessage
        _chatHistory.value = updatedHistory
        _uiState.value = GeminiUiState.Loading
        _isGenerating.value = true
        _isWaiting.value = true

        viewModelScope.launch {
            repository.saveMessage(userMessage)
        }

        activeJob = viewModelScope.launch {
            val fullAccumulated = StringBuilder()
            val aiMessageId = UUID.randomUUID().toString()

            val contents = mutableListOf<Content>()
            contents.addAll(sanitizeHistory(_chatHistory.value.dropLast(1)))
            contents.add(
                content("user") {
                    if (bitmap != null) {
                        image(bitmap)
                    }
                    text(userMessage.content)
                }
            )

            try {
                var emittedChunk = false
                try {
                    withTimeout(35_000L) {
                        generativeModel.generateContentStream(contents).collect { chunk ->
                            val text = chunk.text
                            if (!text.isNullOrEmpty()) {
                                emittedChunk = true
                                _isWaiting.value = false // Token received, transition from waiting to streaming
                                fullAccumulated.append(text)
                                _uiState.value = GeminiUiState.Streaming(fullAccumulated.toString())
                            }
                        }
                    }
                } catch (e: TimeoutCancellationException) {
                    if (!emittedChunk) {
                        Log.w(TAG, "Primary stream timed out, attempting fast lite fallback")
                        // Fallback to lite model
                        withTimeout(25_000L) {
                            val unaryResponse = fastLiteModel.generateContent(contents)
                            val fallbackText = unaryResponse.text.orEmpty()
                            if (fallbackText.isNotBlank()) {
                                fullAccumulated.append(fallbackText)
                            } else {
                                throw IllegalStateException("Model returned empty response.")
                            }
                        }
                    } else {
                        throw e
                    }
                }

                val finalOutput = fullAccumulated.toString()
                if (finalOutput.isNotBlank()) {
                    _uiState.value = GeminiUiState.Success(finalOutput)
                    val modelMsg = ChatMessage(
                        id = aiMessageId,
                        sessionId = sessionId,
                        role = "model",
                        content = finalOutput,
                        timestamp = System.currentTimeMillis()
                    )
                    _chatHistory.value = _chatHistory.value + modelMsg
                    repository.saveMessage(modelMsg)
                } else {
                    _uiState.value = GeminiUiState.Error("Model returned an empty response.")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Gemini query timed out", e)
                val errorMsg = "RayAI took longer than expected to respond. Please try again."
                _uiState.value = GeminiUiState.Error(errorMsg)
                val errorChatMessage = ChatMessage(
                    id = aiMessageId,
                    sessionId = sessionId,
                    role = "model",
                    content = errorMsg,
                    timestamp = System.currentTimeMillis(),
                    isError = true
                )
                _chatHistory.value = _chatHistory.value + errorChatMessage
                repository.saveMessage(errorChatMessage)
            } catch (e: CancellationException) {
                Log.d(TAG, "Query processing cancelled by user")
            } catch (e: Exception) {
                Log.e(TAG, "Gemini query failed", e)
                val errorMsg = e.localizedMessage ?: "Failed to process query."
                _uiState.value = GeminiUiState.Error(errorMsg)
                val errorChatMessage = ChatMessage(
                    id = aiMessageId,
                    sessionId = sessionId,
                    role = "model",
                    content = "Error communicating with RayAI: $errorMsg",
                    timestamp = System.currentTimeMillis(),
                    isError = true
                )
                _chatHistory.value = _chatHistory.value + errorChatMessage
                repository.saveMessage(errorChatMessage)
            } finally {
                _isGenerating.value = false
                _isWaiting.value = false
            }
        }
    }
}
