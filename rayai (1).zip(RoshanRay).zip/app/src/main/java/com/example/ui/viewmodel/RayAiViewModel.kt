package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.DEFAULT_MODEL
import com.example.data.ai.RayAiService
import com.example.data.local.AppDatabase
import com.example.data.model.ChatMessage
import com.example.data.model.ChatSession
import com.example.data.repository.ChatRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

private const val TAG = "RayAiViewModel"

class RayAiViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ChatRepository
    private var aiService: RayAiService

    private val _currentSessionId = MutableStateFlow<String>("")
    val currentSessionId: StateFlow<String> = _currentSessionId.asStateFlow()

    private val _promptInput = MutableStateFlow("")
    val promptInput: StateFlow<String> = _promptInput.asStateFlow()

    private val _attachedImageUri = MutableStateFlow<Uri?>(null)
    val attachedImageUri: StateFlow<Uri?> = _attachedImageUri.asStateFlow()

    private var attachedBitmap: Bitmap? = null

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _streamingMessage = MutableStateFlow<ChatMessage?>(null)
    val streamingMessage: StateFlow<ChatMessage?> = _streamingMessage.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _selectedModel = MutableStateFlow(DEFAULT_MODEL)
    val selectedModel: StateFlow<String> = _selectedModel.asStateFlow()

    private val _temperature = MutableStateFlow(0.7f)
    val temperature: StateFlow<Float> = _temperature.asStateFlow()

    private var activeGenerationJob: Job? = null

    init {
        val db = AppDatabase.getInstance(application)
        repository = ChatRepository(db.chatDao())
        aiService = RayAiService(modelName = _selectedModel.value, temperature = _temperature.value)

        // Initialize with default session or load most recent
        viewModelScope.launch {
            repository.getAllSessions().collect { sessions ->
                if (sessions.isEmpty()) {
                    val newId = UUID.randomUUID().toString()
                    val newSession = ChatSession(
                        id = newId,
                        title = "New Chat",
                        createdAt = System.currentTimeMillis(),
                        updatedAt = System.currentTimeMillis()
                    )
                    repository.createSession(newSession)
                    _currentSessionId.value = newId
                } else if (_currentSessionId.value.isEmpty()) {
                    _currentSessionId.value = sessions.first().id
                }
            }
        }
    }

    val sessions: StateFlow<List<ChatSession>> = repository.getAllSessions().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val currentMessages: StateFlow<List<ChatMessage>> = _currentSessionId.flatMapLatest { sessionId ->
        repository.getMessagesForSession(sessionId)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun setPromptInput(text: String) {
        _promptInput.value = text
    }

    fun setAttachedImage(uri: Uri?, bitmap: Bitmap?) {
        _attachedImageUri.value = uri
        attachedBitmap = bitmap
    }

    fun clearAttachedImage() {
        _attachedImageUri.value = null
        attachedBitmap = null
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    fun startNewSession(initialTitle: String = "New Chat") {
        stopGeneration()
        viewModelScope.launch {
            val newId = UUID.randomUUID().toString()
            val newSession = ChatSession(
                id = newId,
                title = initialTitle,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            repository.createSession(newSession)
            _currentSessionId.value = newId
            _promptInput.value = ""
            clearAttachedImage()
            _errorMessage.value = null
        }
    }

    fun selectSession(sessionId: String) {
        if (_currentSessionId.value != sessionId) {
            stopGeneration()
            _currentSessionId.value = sessionId
            _errorMessage.value = null
        }
    }

    fun renameSession(sessionId: String, newTitle: String) {
        if (newTitle.isNotBlank()) {
            viewModelScope.launch {
                repository.updateSessionTitle(sessionId, newTitle.trim())
            }
        }
    }

    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            val currentList = sessions.value.filter { it.id != sessionId }
            if (_currentSessionId.value == sessionId) {
                if (currentList.isNotEmpty()) {
                    _currentSessionId.value = currentList.first().id
                } else {
                    startNewSession()
                }
            }
        }
    }

    fun clearAllChats() {
        stopGeneration()
        viewModelScope.launch {
            repository.clearAll()
            startNewSession()
        }
    }

    /**
     * Formats current chat history as a clean, structured plain text backup.
     */
    fun exportChatHistoryAsText(): String {
        val session = sessions.value.find { it.id == _currentSessionId.value }
        val title = session?.title ?: "RayAI Conversation"
        val timestamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
            .format(java.util.Date(session?.updatedAt ?: System.currentTimeMillis()))
        val msgList = currentMessages.value

        val builder = java.lang.StringBuilder()
        builder.append("====================================================\n")
        builder.append("RayAI Conversation Backup\n")
        builder.append("Tagline: Intelligence Beyond Limits\n")
        builder.append("Title: $title\n")
        builder.append("Exported: $timestamp\n")
        builder.append("Model: ${_selectedModel.value}\n")
        builder.append("Total Messages: ${msgList.size}\n")
        builder.append("====================================================\n\n")

        if (msgList.isEmpty()) {
            builder.append("(No messages in this conversation)\n")
        } else {
            msgList.forEachIndexed { index, msg ->
                val timeStr = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
                    .format(java.util.Date(msg.timestamp))
                val sender = if (msg.role == "user") "USER" else "RAYAI"
                builder.append("[$timeStr] $sender:\n")
                if (msg.imageUri != null) {
                    builder.append("[Attached Image: ${msg.imageUri}]\n")
                }
                builder.append(msg.content.trim())
                builder.append("\n\n----------------------------------------------------\n\n")
            }
        }
        return builder.toString()
    }

    fun updateSettings(model: String, temp: Float) {
        _selectedModel.value = model
        _temperature.value = temp
        aiService = RayAiService(modelName = model, temperature = temp)
    }

    fun stopGeneration() {
        activeGenerationJob?.cancel()
        activeGenerationJob = null
        _isGenerating.value = false
        val currentStreaming = _streamingMessage.value
        if (currentStreaming != null && currentStreaming.content.isNotBlank()) {
            viewModelScope.launch {
                repository.saveMessage(currentStreaming.copy(isStreaming = false))
                _streamingMessage.value = null
            }
        } else {
            _streamingMessage.value = null
        }
    }

    fun retryLastMessage() {
        val sessionId = _currentSessionId.value
        if (sessionId.isEmpty() || _isGenerating.value) return
        viewModelScope.launch {
            val list = repository.getMessagesList(sessionId)
            val lastUserMsg = list.lastOrNull { it.role == "user" }
            if (lastUserMsg != null) {
                sendMessage(lastUserMsg.content)
            }
        }
    }

    fun sendMessage(userText: String? = null) {
        val query = (userText ?: _promptInput.value).trim()
        if (query.isEmpty() && attachedBitmap == null) return

        val sessionId = _currentSessionId.value
        if (sessionId.isEmpty()) return

        // Clear input bar
        _promptInput.value = ""
        val bitmapToSend = attachedBitmap
        val uriToSend = _attachedImageUri.value
        clearAttachedImage()
        _errorMessage.value = null

        viewModelScope.launch {
            // Save user message
            val userMsg = ChatMessage(
                id = UUID.randomUUID().toString(),
                sessionId = sessionId,
                role = "user",
                content = query.ifEmpty { "Analyze this image" },
                imageUri = uriToSend?.toString(),
                timestamp = System.currentTimeMillis()
            )
            repository.saveMessage(userMsg)

            // Auto-update session title if it's currently "New Chat"
            val currentSession = repository.getSession(sessionId)
            if (currentSession != null && (currentSession.title == "New Chat" || currentSession.title.isBlank())) {
                val autoTitle = if (query.isNotBlank()) {
                    if (query.length > 28) query.take(28) + "..." else query
                } else {
                    "Image Analysis"
                }
                repository.updateSessionTitle(sessionId, autoTitle)
            }

            // Prepare for AI stream
            val aiMsgId = UUID.randomUUID().toString()
            val streamingMsg = ChatMessage(
                id = aiMsgId,
                sessionId = sessionId,
                role = "model",
                content = "",
                timestamp = System.currentTimeMillis(),
                isStreaming = true
            )
            _streamingMessage.value = streamingMsg
            _isGenerating.value = true

            // Collect history for context
            val history = repository.getMessagesList(sessionId)

            activeGenerationJob = viewModelScope.launch {
                val fullAccumulated = StringBuilder()
                try {
                    aiService.streamResponse(
                        prompt = userMsg.content,
                        history = history.filter { it.id != userMsg.id },
                        bitmap = bitmapToSend
                    ).collect { chunk ->
                        fullAccumulated.append(chunk)
                        _streamingMessage.value = streamingMsg.copy(content = fullAccumulated.toString())
                    }

                    val finalContent = fullAccumulated.toString()
                    if (finalContent.isNotBlank()) {
                        repository.saveMessage(
                            streamingMsg.copy(
                                content = finalContent,
                                isStreaming = false
                            )
                        )
                    } else {
                        repository.saveMessage(
                            streamingMsg.copy(
                                content = "I received your message, but no content was generated.",
                                isStreaming = false
                            )
                        )
                    }
                } catch (e: TimeoutCancellationException) {
                    Log.e(TAG, "Request timed out", e)
                    _errorMessage.value = "RayAI response timed out. Please try again."
                    val timeoutContent = if (fullAccumulated.isNotBlank()) {
                        fullAccumulated.toString() + "\n\n*(Response timed out)*"
                    } else {
                        "RayAI took longer than expected to connect. Please check your connection and tap retry."
                    }
                    repository.saveMessage(
                        streamingMsg.copy(
                            content = timeoutContent,
                            isStreaming = false,
                            isError = true
                        )
                    )
                } catch (e: CancellationException) {
                    Log.d(TAG, "Response generation cancelled by user")
                } catch (e: Exception) {
                    Log.e(TAG, "RayAI generation failed", e)
                    val errText = e.localizedMessage ?: "Unknown error occurred"
                    _errorMessage.value = errText
                    repository.saveMessage(
                        streamingMsg.copy(
                            content = "Error communicating with RayAI: $errText",
                            isStreaming = false,
                            isError = true
                        )
                    )
                } finally {
                    _isGenerating.value = false
                    _streamingMessage.value = null
                }
            }
        }
    }
}
